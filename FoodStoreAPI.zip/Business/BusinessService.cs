
public class BusinessService
{
    private readonly IProductService _productService;
    private readonly ICategoryService _categoryService;

    public BusinessService(IProductService productService, ICategoryService categoryService)
    {
        _productService = productService;
        _categoryService = categoryService;
    }

    public async Task<IEnumerable<Product>> GetAllProducts() => await _productService.GetProducts();
    public async Task CreateProduct(Product product) => await _productService.CreateProduct(product);
}
