
public interface ICategoryService
{
    Task<IEnumerable<Category>> GetCategories();
    Task CreateCategory(Category category);
}

public class CategoryService : ICategoryService
{
    private readonly ICategoryRepository _categoryRepository;

    public CategoryService(ICategoryRepository categoryRepository)
    {
        _categoryRepository = categoryRepository;
    }

    public async Task<IEnumerable<Category>> GetCategories() => await _categoryRepository.GetAllCategories();
    public async Task CreateCategory(Category category) => await _categoryRepository.CreateCategory(category);
}
