
public interface IProductService
{
    Task<IEnumerable<Product>> GetProducts();
    Task CreateProduct(Product product);
}

public class ProductService : IProductService
{
    private readonly IProductRepository _productRepository;

    public ProductService(IProductRepository productRepository)
    {
        _productRepository = productRepository;
    }

    public async Task<IEnumerable<Product>> GetProducts() => await _productRepository.GetAllProducts();
    public async Task CreateProduct(Product product) => await _productRepository.CreateProduct(product);
}
