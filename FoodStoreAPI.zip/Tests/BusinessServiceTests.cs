
public class BusinessServiceTests
{
    private readonly Mock<IProductService> _mockProductService;
    private readonly Mock<ICategoryService> _mockCategoryService;
    private readonly BusinessService _businessService;

    public BusinessServiceTests()
    {
        _mockProductService = new Mock<IProductService>();
        _mockCategoryService = new Mock<ICategoryService>();
        _businessService = new BusinessService(_mockProductService.Object, _mockCategoryService.Object);
    }

    [Fact]
    public async Task GetAllProducts_ShouldReturnProducts()
    {
        _mockProductService.Setup(x => x.GetProducts()).ReturnsAsync(new List<Product> { new Product { Id = 1, Name = "Product1", Price = 10.0M } });
        
        var result = await _businessService.GetAllProducts();
        
        Assert.NotEmpty(result);
        Assert.Equal(1, result.First().Id);
    }

    [Fact]
    public async Task CreateProduct_ShouldCallCreateProduct()
    {
        var product = new Product { Id = 1, Name = "Product1", Price = 10.0M };
        
        await _businessService.CreateProduct(product);
        
        _mockProductService.Verify(x => x.CreateProduct(It.IsAny<Product>()), Times.Once);
    }
}
